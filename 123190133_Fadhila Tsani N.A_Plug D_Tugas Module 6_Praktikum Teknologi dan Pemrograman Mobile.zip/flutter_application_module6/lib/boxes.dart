import 'package:hive/hive.dart';
import 'package:flutter_application_module6/models/cart.dart';

class HiveBoxes {
  static Box<Item> getItems() => Hive.box<Item>('items');
}
